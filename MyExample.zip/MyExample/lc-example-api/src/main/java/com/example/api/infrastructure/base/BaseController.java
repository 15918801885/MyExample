package com.example.api.infrastructure.base;

import com.example.api.infrastructure.constant.ResultHelper;
import com.example.api.infrastructure.constant.ResultModel;
import com.example.api.infrastructure.constant.ReturnCode;
import lombok.extern.slf4j.Slf4j;

/**
 * @Auther: ALLEN C LIANG
 * @Date: 2021/5/9 02:38
 * @Description:
 */
@Slf4j
public class BaseController {

    /**
     * format 失败 response。
     *
     * @param message 内容
     * @return
     */
    protected ResultModel errorResponse(String message) {
        return ResultHelper.error(ReturnCode.ERROR, message);
    }

    /**
     * format 失败 response。
     *
     * @param message 内容
     * @return
     */
    protected ResultModel errorResponse(String code, String message) {
        return ResultHelper.error(code, message);
    }

    /**
     * 成功的response
     *
     * @param message 内容
     * @param data    实体
     * @return ResponseDto
     */
    protected <T> ResultModel<T> successResponse(String message, T data) {
        return ResultHelper.success(ReturnCode.SUCCESS, message, data);
    }

    /**
     * 成功的response
     *
     * @param message 内容
     * @return ResponseDto
     */
    protected ResultModel successResponse(String message) {
        return ResultHelper.success(ReturnCode.SUCCESS, message);
    }

}