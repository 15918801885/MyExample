package com.example.api.service.cluster;

import com.example.api.entity.cluster.StuT;

import java.util.List;

/**
 * @Auther: ALLEN C LIANG
 * @Date: 2021/5/8 18:25
 * @Description:
 */
public interface StuTService {

    List<StuT> getAllStuT();
}

