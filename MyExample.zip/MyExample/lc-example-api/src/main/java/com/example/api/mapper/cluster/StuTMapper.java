package com.example.api.mapper.cluster;

import com.example.api.entity.cluster.StuT;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Auther: ALLEN C LIANG
 * @Date: 2021/5/8 18:35
 * @Description:
 */
@Mapper
public interface StuTMapper {

    List<StuT> getAllStuT();

}
