package com.example.api.infrastructure.constant;

/**
 * @Auther: ALLEN C LIANG
 * @Date: 2021/5/9 02:37
 * @Description:
 */
public class ResultHelper {
    public ResultHelper() {
    }

    public static <T> ResultModel<T> success(String code, String message, T data) {
        return new ResultModel(code, message, data);
    }

    public static <T> ResultModel<T> success(String code, String message) {
        return new ResultModel(code, message, (Object) null);
    }

    public static <T> ResultModel<T> error(String code, String message) {
        return new ResultModel(code, message);
    }
}
