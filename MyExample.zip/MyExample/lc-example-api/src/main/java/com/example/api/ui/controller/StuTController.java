package com.example.api.ui.controller;

import com.example.api.entity.cluster.StuT;
import com.example.api.infrastructure.base.BaseController;
import com.example.api.infrastructure.constant.ResultModel;
import com.example.api.service.cluster.StuTService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Auther: ALLEN C LIANG
 * @Date: 2021/5/9 02:41
 * @Description:
 */
@RestController
@RequestMapping("/api/test")
@Api(tags = "testapi")
public class StuTController extends BaseController {

    @Autowired
    private StuTService stuTService;

    @ResponseBody
    @GetMapping("/getInfo")
    @ApiOperation(value = "getInfo Test", notes = "getInfo")
    public ResultModel getInfo() {
        List<StuT> list = stuTService.getAllStuT();
        return (list.size() <= 0) ? this.errorResponse("Request Fail！") : this.successResponse("Request Success", list);
    }


}
