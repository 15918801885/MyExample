package com.example.api.service.cluster.impl;

import com.example.api.entity.cluster.StuT;
import com.example.api.mapper.cluster.StuTMapper;
import com.example.api.service.cluster.StuTService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Auther: ALLEN C LIANG
 * @Date: 2021/5/8 18:25
 * @Description:
 */
@Service
public class StuTServiceImpl implements StuTService {

    @Autowired
    private StuTMapper stuTMapper;

    @Override
    public List<StuT> getAllStuT() {
        return stuTMapper.getAllStuT();
    }
}
