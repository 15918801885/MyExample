package com.example.api;

import com.example.api.entity.cluster.StuT;
import com.example.api.service.cluster.StuTService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

/**
 * 字典单元测试
 *
 * @author cliang
 * @since 2020/10/22 16:35
 */
@SpringBootTest
public class DictionaryServiceTest {

    @Autowired
    private StuTService stuTService;

    @Test
    public void stuTTest1() {
        List<StuT> stuTs = stuTService.getAllStuT();
        System.out.println(stuTs.size());
    }

}
